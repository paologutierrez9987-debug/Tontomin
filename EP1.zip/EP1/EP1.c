#include <stdio.h>
#include "F.h"
#include <string.h>
int pro = 0;
float totin=0;
float totpro[5]={0};
int main(int argc, char *argv[])
{
    char prod[5][20], busc[20];
    int cant[5], op, cont;
    float precio[5];
    do
    {
        printf("---TIENDA---\n");
        printf("1. Registro de producto\n");
        printf("2. Inventario\n");
        printf("3. Vender\n");
        printf("4. Calculo de ventas\n");
        printf("5. Producto mas caro y mas barato\n");
        printf("6. Salir\n");
        printf(">> ");
        op=validarnum(0);
        switch (op)
        {
        case 1:
            registro(prod, precio, cant); 
            break;
            case 2:
            mostrar(prod, precio, cant);
            break;
            case 3:
            vender(prod, precio, cant, busc);
            break;
            case 4:
            calculo(prod, precio, cant); 
            break;
            case 5:
            carbar(prod, precio, cant);
            break;
            case 6:
            return 0;
        default:
        printf("Opcion no establecida. \n");
            break;
        }
        printf("\nVolver al menu? 1.Si 2.No\n");
        printf(">> ");
        cont=validarnum(0);
    } while (cont == 1);
    return 0;
}