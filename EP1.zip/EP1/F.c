#include <stdio.h>
#include <string.h>
#include "F.h"
void ingreso(char arr[], int n){
    fgets(arr, n, stdin);
    arr[strcspn(arr, "\n")]='\0';
}
float validarnum(float a){
    int val=0;
    float num;
    do{
        val=scanf("%f", &num);
        while((getchar())!='\n');
        if (num<=a|| val!=1){
            printf("Ingreso invalido. Intente nuevamente: ");
                }
    }
    while(num<=a|| val!=1);
    return num;
}
void registro(char arr[5][20], float pre[], int cant[]){
    printf("---REGISTRO DE PRODUCTO---\n");
    printf("Nombre: ");
    ingreso(arr[pro], 20);
    printf("Precio: $");
    pre[pro]=validarnum(0);
    printf("Stock: ");
    cant[pro]=validarnum(0);
    pro++;
}
void mostrar(char arr[5][20], float pre[], int cant[]){
    if(pro==0){
        printf("Sin productos registrados\n");
    }
    else{
        printf("---PRODUCTOS REGISTRADOS---\n");
        printf("%-20s %-10s %-10s\n", "Producto", "Precio", "Stock");
        for (int i = 0; i < pro; i++)
        {
            printf("%-20s %-10.2f %-10d\n", arr[i], pre[i], cant[i]);
        }
    }
}
void vender(char arr[5][20], float pre[], int cant[], char buscar[20]){
    int enc=0, ven, cantven;
    if(pro==0){
        printf("Sin productos registrados\n");
    }
    else{
    printf("---VENDER PRODUCTO---\n");
        printf("%-20s %-10s %-10s\n", "Producto", "Precio", "Stock");
        for (int i = 0; i < pro; i++)
        {
            printf("%-20s %-10.2f %-10d\n", arr[i], pre[i], cant[i]);
        }
    printf("Producto a vender: ");
    ingreso(buscar, 20); 
    for (int i = 0; i < pro; i++)
    {
        if(strcasecmp(buscar, arr[i])==0){
            enc=1;
            ven=i;
            break;
        }
    }
    if(enc==1){
        printf("Cantidad a vender: ");
        cantven=validarnum(0);
        while(cantven>cant[ven]){
            printf("Stock insuficiente. Ingrese nuevamente: ");
            cantven=validarnum(0);
        }
        totpro[ven]+=cantven*pre[ven];
        totin+=totpro[ven];
        cant[ven]-=cantven;
        printf("Total a pagar: $%.2f", totpro[ven]);
    }
    if (enc==0){
        printf("Producto no encontrado\n");
    }
    }
}
void calculo(char arr[5][20], float pre[], int cant[]){
    if(pro==0){
        printf("Sin productos registrados\n");
    }
    else{
        printf("---VENTAS REALIZADAS---\n");
        printf("%-20s %-10s %-10s %-10s\n", "Producto", "Precio", "Stock", "Venta");
        for (int i = 0; i < pro; i++)
        {
            printf("%-20s $%-10.2f %-10d $%-10.2f\n", arr[i], pre[i], cant[i], totpro[i]);
        }
        printf("Ganancias totales: $%.2f", totin);
    }
}
void carbar(char arr[5][20], float pre[], int cant[]){
    float car, bar;
    bar=pre[0];
    car=pre[0];
    if(pro==0){
        printf("Sin productos registrados\n");
    }
    else{
        for (int i = 0; i < pro; i++)
        {
            if(pre[i]>car){
                car=pre[i];
            }
            if(pre[i]<bar){
                bar=pre[i];
            }
        } 
        printf("\nProducto(s) mas caro(s): \n");
        for (int i = 0; i < pro; i++)
        {
            if(pre[i]==car){
                printf("%-10s $%-10.2f\n", arr[i], pre[i]);
            }
        }
        printf("\nProducto(s) mas barato(s): \n");
        for (int i = 0; i < pro; i++)
        {
            if(pre[i]==bar){
                printf("%-10s $%-10.2f\n", arr[i], pre[i]);
            }
        }
        if(car==bar){
                printf("Productos de igual precio: \n");
                for (int i = 0; i < pro; i++)
                {
                     printf("%-10s $%-10.2f\n", arr[i], pre[i]);
                }

            } 
    }
}